const KEYS = {
    'googleOauth': {
        'clientID': "948103666603-qj71gukhm51805vof2861q3huuu1uetg.apps.googleusercontent.com",
        'clientSecret': "M61wWOyIJvJzq-3LRjQt277b",
        'callback': '/auth/google/redirect'
    },
    "session_key": "secret123"
}

module.exports = KEYS




